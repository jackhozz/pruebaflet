import flet as ft
import asyncio

def main(page: ft.Page):
    bs=ft.AlertDialog(
        title=ft.Text("Hola"),
        content=ft.Column([ft.Text("¿me amas?"),ft.Image(src="https://github.com/jackhozz/Proyecto-Streamlit/blob/main/WhatsApp%20Image%202025-01-22%20at%2012.36.06%20PM.jpeg?raw=true",width=100,height=100)]),
        actions=[
            ft.TextButton("si", on_click=lambda e: page.close(bs)),
            ft.TextButton("no", on_click=lambda e: page.close(bs))
        ],
        on_dismiss=lambda e: print("Dialog dismissed")
    )
    column = ft.Column([ft.Text("Hola, dejemos de tratarnos mal"),ft.ElevatedButton("Click me",on_click=lambda e: page.open(bs))])
    page.add(column)
    page.update() # Asegúrate de que la página se actualice al inicio

if __name__ == "__main__":
    ft.app(target=main)
